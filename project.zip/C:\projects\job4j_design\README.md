# job4j_design
# Project topics:

- Maven
- AssertJ
- Data structures and algorithms
- Input-Output
- SQL
- JDBC
- Garbage Collection
- TDD, SRP, OCP, LSP, ISP, DIP